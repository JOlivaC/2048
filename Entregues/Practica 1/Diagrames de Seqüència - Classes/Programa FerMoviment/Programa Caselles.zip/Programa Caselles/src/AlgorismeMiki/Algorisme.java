package AlgorismeMiki;
import java.util.List;
import Domini.*;


public abstract class Algorisme {
	/* tipusMov 
	 * 0 = Amunt
	 * 1 = Avall
	 * 2 = Dreta
	 * 3 = Esquerra
	 */
	
	/* Post: Mou les caselles de l'estructura Matriu en el sentit del moviment, retorna la puntuaci�
	 * del moviment 
	 */
	public static int FerMoviment(List<List<Casella>> Matriu,int tipusMov){
		
		
		
		
		
		return 0;	
	}
}
