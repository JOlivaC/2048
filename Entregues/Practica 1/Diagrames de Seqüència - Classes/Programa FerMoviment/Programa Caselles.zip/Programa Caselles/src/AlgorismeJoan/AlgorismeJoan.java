package AlgorismeJoan;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

import Domini.Casella;


public abstract class AlgorismeJoan {

	
	public static int FerMoviment(List<List<Casella>> LC,int TipusMov){
		Set<List<Casella>> elements = Separar(LC,TipusMov);
		int ret = 0;
		for (List<Casella> element: elements){
			ret += Moure(element);
		}
		return ret;
	}
	
	private static List<Casella> Desenvolupar(List<List<Casella>> mat){
		List<Casella> ret = new ArrayList<Casella>();
		for (List<Casella> fila : mat){
			for (Casella c: fila){
				ret.add(c);
			}
		}
		return ret;
	}
	
	private static Set<List<Casella>> Organitzar(List<Casella> LC,int dimensio){
		Set<List<Casella>> ret = new HashSet<List<Casella>>();
		for (int i = 0; i < dimensio; i ++){
			ret.add(LC.subList(i * dimensio, i * dimensio + (dimensio)));
		}
		return ret;
	}
	
	private static Set<List<Casella>> Separar(List<List<Casella>> LC,int TipusMov){
		
		ComparadorCasella c = ComparadorCasella.get(TipusMov);
		List<Casella> totes = Desenvolupar(LC);
		totes.sort(c);
		return Organitzar(totes,LC.size());
			
	}
	
	
	@SuppressWarnings("unused")
	private static int Moure3(List<Casella> LC){
	    ListIterator<Casella> ext =  LC.listIterator();
	    ext.next();
	    Casella UltimaFusio = null;
	    int ret = 0;
	    while (ext.hasNext()){
	    	Casella Actual = ext.next();
	    	if (Actual.TeNumero()){

	            ListIterator<Casella> bloc = LC.listIterator(ext.nextIndex());
	            bloc.previous();
	            Casella Bloc = bloc.previous();
	            while(bloc.hasPrevious() && !Bloc.TeNumero()){
	                Bloc = bloc.previous();
	            }
	            ListIterator<Casella> novaP = LC.listIterator(bloc.nextIndex());
	            
	            
	            if (Bloc.TeNumero()) novaP.next();

	            Casella Nova = novaP.next();
	            novaP.previous();
	            
	            Actual.Moure(Nova);        

	            if (novaP.hasPrevious() && Bloc != UltimaFusio) {
	            if (Bloc.getNumero() == Nova.getNumero()){
	            	ret += Bloc.Fusionar(Nova);
	                UltimaFusio = Bloc;
	            }
	        }
	        }
	   }
	    return ret;
	}
	

	@SuppressWarnings("unused")
	private static int Moure2(List<Casella> LC){
		Casella UltimaFusio = null;
		int ret = 0;
		for (int i = 1; i < LC.size(); i++){
			if (LC.get(i).TeNumero()){
				int j = i;
				boolean Primer = j == 0;
				
				while(!Primer && !LC.get(j -1).TeNumero()){
					LC.get(j).Moure(LC.get(j -1));
					j --;
					Primer = j == 0;
				}
				
				if (!Primer && UltimaFusio != LC.get(j-1)){
					if (LC.get(j).getNumero() == LC.get(j-1).getNumero()){
						ret += LC.get(j-1).Fusionar(LC.get(j));
						UltimaFusio = LC.get(j-1);
					}
				}
			}	
		}
		return ret;
	}
	
	@SuppressWarnings("unused")
	private static int Moure(List<Casella> LC){
	    ListIterator<Casella> ext =  LC.listIterator();
	    ext.next();
	    Casella UltimaFusio = null;
	    int result = 0;
	    while (ext.hasNext()){
	    	Casella Actual = ext.next();
	    	if (Actual.TeNumero()){

	            ListIterator<Casella> bloc = LC.listIterator(ext.nextIndex());
	            bloc.previous();
	            Casella Bloc = bloc.previous();
	            while(bloc.hasPrevious() && !Bloc.TeNumero()){
	                Bloc = bloc.previous();
	            }
	            
	            
	            
	            if (Bloc.TeNumero()) {
	            	if (Bloc.getNumero() == Actual.getNumero() && Bloc != UltimaFusio){
		            	result += Bloc.Fusionar(Actual);
		            	UltimaFusio = Bloc;
	            	}
	            	else {
	            		ListIterator<Casella> novaP = LC.listIterator(bloc.nextIndex());
		            	novaP.next(); 
		            	Casella Nova = novaP.next();
		            	Actual.Moure(Nova);
	            	}
	            }
	            else Actual.Moure(Bloc);


	        }
	   }
	    return result;
	}
	
}
