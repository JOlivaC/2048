package AlgorismeJoan;
import java.util.Comparator;

import Domini.Casella;

public class dreta extends ComparadorCasella implements  Comparator<Casella>{

		@Override
		public int compare(Casella arg0, Casella arg1) {
				if (arg0.getFila() < arg1.getFila()) return -1;
				else if (arg0.getFila() > arg1.getFila()) return 1;
				else {
					if (arg0.getColumna() > arg1.getColumna()) return -1;
					else return 1;
				}
		}
	};