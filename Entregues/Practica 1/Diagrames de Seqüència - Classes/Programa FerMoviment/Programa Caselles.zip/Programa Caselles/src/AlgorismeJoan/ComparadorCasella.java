package AlgorismeJoan;
import java.util.Comparator;

import Domini.Casella;


public abstract class ComparadorCasella implements Comparator<Casella>{
	public static ComparadorCasella get(int TipusMov){
		if (TipusMov == 0) return new amunt();
		else if (TipusMov == 1) return new avall();
		else if (TipusMov == 2) return new dreta();
		else if (TipusMov == 3) return new esquerra();
		else return null;
	}

	
	
	
	
	
	
	
	
	
	
	
}

