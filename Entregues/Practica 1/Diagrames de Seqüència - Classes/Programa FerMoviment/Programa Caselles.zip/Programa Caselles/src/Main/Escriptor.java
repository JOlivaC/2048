package Main;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


public class Escriptor {
	public static void EscriureTaulers(String fitxer,int[][][] tauler){
		
		try {
			File f = new File(fitxer);
			if (!f.exists()) f.createNewFile();
			FileWriter fv;
			fv = new FileWriter(f);
			EscriuFitxer(tauler,fv);
			fv.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	private static void EscriuFitxer(int[][][] tauler,FileWriter f) throws IOException{
		for (int i = 0; i < tauler.length; i++){
			for (int j = 0; j < tauler[i].length; j++){
				f.write(Escriu(tauler[i][j]));
				f.write(System.getProperty("line.separator"));	
			}
		}
	}

	
	private static String Escriu(int[] linia){
		String ret = new String();
		for (int i = 0; i < linia.length ;  i ++){
			ret += String.valueOf(linia[i]);
		}
		return ret;
	}
}
