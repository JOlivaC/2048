package Main;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Vector;


public abstract class Lector {

	public static int[][][] LlegirTaulers(String fitxer,int Dimensio){
		return Lector.Separar(Lector.Llegeix(fitxer),Dimensio);
	}
	public static int[][][] Separar(int[][] matriu,int dimensio){
		int linies = matriu.length;
		int[][][] ret = new int[linies / dimensio][][];
		for (int linea = 0; linea < linies; linea += dimensio){
			int[][] grup;
			grup = new int[dimensio][dimensio];
			for (int i = 0; i < dimensio; i ++){
				for (int j = 0; j < dimensio; j++){
					grup[i][j] = matriu[linea + i][j]; 
				}
			}
			ret[linea/dimensio] = grup;			
		}
		return ret;
	}
	
	public static int[][] Llegeix(String fitxer){
		File f = new File(fitxer);
		Vector<int[]> v = new Vector<int[]>();
		try {
			Scanner s = new Scanner(f);
			int i = 0;
			while (s.hasNextLine()){
				String linea = s.nextLine();
				int[] split = Lector.Converteix(linea);
				if (!(split.length == 0)){
					v.add(i,split);
					i++;
				}
			}
			s.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		int[][] ret = new int[v.size()][];
		for (int i = 0; i < v.size(); i++) ret[i] = v.get(i);
		return ret;
		
	}
	
	private static int[] Converteix(String linea){
		int i = 0;
		int[] res = new int[linea.length()];
		for (i = 0; i < linea.length(); i++){
			res[i] =Character.getNumericValue(linea.charAt(i));
		}
		return res;
	}
	
}
