package Main;
import java.util.Scanner;
import java.util.Vector;
import Domini.*;

public class Main {
		public static void main(String argv[]){
				
				String dir = System.getProperty("user.dir");
				dir +=  "\\jp";
				int tipusalg = Integer.parseInt(argv[0]);
				int dimensio = Integer.parseInt(argv[1]);
				int tipusmov = Integer.parseInt(argv[2]);
				
				
				int[][][] matrius = Lector.LlegirTaulers(dir + "\\In.txt", dimensio);
				int[][][] resultat = new int[matrius.length][][];
				int[][][] out = Lector.LlegirTaulers(dir + "\\Out" + tipusmov + ".txt", dimensio);
				
				for (int i = 0; i < matrius.length ; i++){
					MatriuCaselles x = new MatriuCaselles(matrius[i],dimensio,dimensio);
					x.FerMoviment(tipusmov,tipusalg);
					resultat[i] = x.imprimir();
				}
				Vector<Integer> Fallades = new Vector<Integer>();
				boolean res = Comparar(resultat,out,Fallades);

				
				if (res){
					System.out.print("Tot Correcte!\n");
				} else{
					System.out.print("l�nies que fallen:\n");
					System.out.print(Fallades.toString() + "\n");
					System.out.print("indica un nom de fitxer per escriure la sortida de tot l'algorisme: (Si no vols escriure prem enter)\n");
					Scanner in = new Scanner(System.in);
					String file = in.nextLine();
					if (file != null) Escriptor.EscriureTaulers(dir + "\\" + file,resultat);
					in.close();
				}
		}
		
		public static boolean Comparar(int[][][] x,int[][][] y,Vector<Integer> fallades){
			for (int i = 0; i < x.length; i++){
				for (int j = 0; j < x[i].length; j++){
					for (int k = 0; k < x[i][j].length; k++){
						if (x[i][j][k] != y[i][j][k]) fallades.add(i * x[i].length + j);
					}
				}
			}
			return fallades.size() == 0;
		}
}
