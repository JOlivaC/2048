package Domini;
import java.util.ArrayList;
import java.util.List;

import AlgorismeJoan.*;
import AlgorismeMiki.Algorisme;


public class MatriuCaselles {
	private List<List<Casella>> Tauler;
	
	public MatriuCaselles(int[][] numeros,int files,int columnes){
		Tauler = new ArrayList<List<Casella>>();
		
		for (int i = 0; i < files; i ++){
			Tauler.add(i,new ArrayList<Casella>());
			for (int j = 0; j < columnes; j++){
				Tauler.get(i).add(j,new Casella(i,j,numeros[i][j]));
			}
		}
	}
	
	public int[][] imprimir(){
		int[][] ret = new int[Tauler.size()][Tauler.size()];
		for (List<Casella> i: Tauler){
			for (Casella j: i){
				ret[j.getFila()][j.getColumna()] = Casella.PrintNumero(j);
			}	
		}	
		return ret;
	}
	
	public void FerMoviment(int tipusmov,int tipusAlg){
		if (tipusAlg == 0) AlgorismeJoan.FerMoviment(Tauler, tipusmov);
		if (tipusAlg == 1) Algorisme.FerMoviment(Tauler, tipusmov);
	}
	
	
}
