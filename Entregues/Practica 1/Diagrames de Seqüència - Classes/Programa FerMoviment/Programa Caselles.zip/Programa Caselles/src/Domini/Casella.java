package Domini;

public class Casella {
	private int i;
	private int j;
	private Integer numero;
	
	Casella(int i,int j){this.i = i;this.j = j;numero = null;}
	Casella(int i,int j,int numero){
		this.i = i;
		this.j = j;
		if (numero != 0) this.numero = numero;
		else this.numero = null;
	}
	public boolean TeNumero(){return numero != null;}
	public void setNumero(int n){numero = n;}
	public void borrarNumero(){numero = null;}
	public int getNumero(){return numero;}
	
	/* Intercanvia els nombres */
	public void Moure(Casella c){
		Integer aux = numero;
		numero = c.numero;
		c.numero = aux;
	}
	/* El Parametre de Classe �s la nova casella resultant, c s'elimina (es posa a null el seu numero) */
	public int Fusionar(Casella c){
		int n = numero + c.numero;
		c.borrarNumero();
		numero = n;
		return n;		
	}
	/* Pre: Ambdues caselles tenen numero */
	public boolean MateixNumero(Casella c){
		return c.numero == this.numero;
	}
	public int getFila(){return i;}
	public int getColumna(){return j;}
	
	public static int PrintNumero(Casella c){
		if (c.TeNumero()) return c.getNumero();
		else return 0;
	}
	public String toString(){
		return String.valueOf(numero);	
	}
}
