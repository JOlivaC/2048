�S DEL PROGRAMA:

REGLA MESTRA: NOM�S CAL MODIFICAR LA CLASSE ALGORISMEMIKI/ALGORISME. NO CAL TOCAR RES M�S (SI CAS AFEGIR NOVES CLASSES)

Parametres:
El programa rep exactament 3 par�metres de tipus num�ric i si en falla algun no funcionar�, s�n aquests:

	1: Tipus d'algorisme a executar: 	0 = Algorisme Predefinit
						1 = Algorisme Per Realitzar dins de la classe Algorisme

	2: Mida de la matriu en els jocs de prova (normalment 4)

	3: Tipus de Moviment a realitzar(el programa ja escull el joc de proves adeq�at segons aquest par�metre)
		0 = Amunt
		1 = Avall
		2 = Dreta
		3 = Esquerra	

	Exemple d'�s:
	java -jar "miprograma.jar" 0 4 2

Sortida:
	Si el resultat �s correcte es notifica.
	Sino s'exposen les l�nies del resultat que han fallat respecte a la bona, a m�s es pot indicar un nom de fitxer per
	imprimir el resultat, s'imprimir� a "jp/nomfitxer" es sobreescriur� qualsevol fitxer existent

Operacions per utilitzar de Casella:

	public boolean TeNumero();

	public void setNumero(int n);

	public void borrarNumero();

	/* Pre: La casella te numero */
	public int getNumero();
	
	/* Pre: Cert; 
	Post : Intercanvia els numeros de les caselles c i parametre de classe, si una de les caselles �s buida
	llavors �s com si fessim un moviment */
	public void Moure(Casella c);

	/* pre: ambdues caselles t�nen numero;
	 post: El Parametre de Classe �s la nova casella resultant, c s'elimina (es posa a null el seu numero) */
	public int Fusionar(Casella c);

	/* Pre: Ambdues caselles tenen numero */
	public boolean MateixNumero(Casella c){
		return c.numero == this.numero;
	}

	public int getFila();
	public int getColumna();

Notes Extra:
	Els atributs fila i columna d'una casella s�n del 0 al 3. No pas del 1 al 4
